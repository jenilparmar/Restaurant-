import re
from flask import Flask, render_template, request
import random
import pymongo
# ///////////////////////////////DATABASE////////////////////
client = pymongo.MongoClient("mongodb://localhost:27017")
db = client["Restaurant"]
collection = db["Items"]
items_cursor = collection.find()
k = []
for item in items_cursor:
    k.append(item)
l=k.copy()
Vastu = k[0]
ITEMS = l[0]
del ITEMS["_id"]
def AddToDatabase(thali, dish, price):
    global ITEMS  # To access the global ITEMS dictionary
    
    # Check if the "thali" already exists in ITEMS
    if thali in ITEMS:
        ITEMS[thali][dish] = int(price)
    else:
        # If "thali" doesn't exist, create a new entry
        ITEMS[thali] = {dish: int(price)}
    
    # Update the MongoDB collection with the updated ITEMS
    collection.update_one({}, {"$set": ITEMS})
    
    print("Added")

def delete_items(key1, key2):
    for category, item in zip(key1, key2):
        collection.update_one({}, {"$unset": {category + "." + item: ""}})
        
        # Check if all items of the category are cleared
        if not collection.find_one({category: {"$exists": True}}):
            # Delete the entire category from the collection
            collection.update_one({}, {"$unset": {category: ""}})
    print("Deleted")


# /////////////////////////FLASK////////////////////
app = Flask(__name__)

quotes = [
    "Life is uncertain. Eat dessert first.",
    "All you need is love. But a little chocolate now and then doesn't hurt.",
    "There is no sincerer love than the love of food.",
    "Cooking is like love. It should be entered into with abandon or not at all.",
    "People who love to eat are always the best people.",
    "Food is symbolic of love when words are inadequate.",
    "The only thing I like better than talking about food is eating.",
    "One cannot think well, love well, sleep well, if one has not dined well.",
    "Food is our common ground, a universal exp1erience.",
    "Eat breakfast like a king, lunch like a prince, and dinner like a pauper."
]
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/items')
def items():
    dish = request.args.get('dish')
    if dish not in ITEMS:
        return f"Invalid Dish: {dish}"
    thali_data = ITEMS[dish]
    return render_template('Items.html', dish=dish, Thali=thali_data)

@app.route('/submit_order', methods=['POST'])
def submit_order():
    if request.method == 'POST':
        selected_items = request.form.getlist('item')
        quantities = {item: int(request.form.get(f'{item}_quantity', 0)) for item in selected_items}

        total_price = 0
        for item, quantity in quantities.items():
            for category, items in ITEMS.items():
                if item in items:
                    total_price += items[item] * quantity
                    break
        return render_template('OrderSuccess.html', quantities=quantities, total_price=total_price, ITEMS={key: value for key, value in ITEMS.items() if key != '_id'})

@app.route('/Order')
def Order():
    q = quotes[random.randint(0,len(quotes)-2)]
    return render_template('Order.html', ITEMS={key: value for key, value in ITEMS.items() if key != '_id'}, q=q)
@app.route('/Added' ,methods=["GET","POST"])
def Added():
    if request.method=="POST":
        Thali = request.form['Thali']
        Dish = request.form['Dish']
        Price = request.form['Price']
        AddToDatabase(Thali,Dish,Price)
        return render_template('Added.html',Thali=Thali,Dish=Dish,Price=Price)
    else:
        return "Nothing To Add!!"
@app.route('/Management',methods=['POST','GET'])
def Management():
    if request.method=="GET":
        return render_template('Authentication.html')
    if request.method=="POST":
        
        username = request.form['username']
        password = request.form['password']
        if True:  
            return render_template('Management.html',ITEMS={key: value for key, value in ITEMS.items() if key != '_id'})




@app.route('/RemoveItem', methods=["POST"])
def RemoveItem():
    if request.method == "POST":
        checked_items = []
        key1 = []
        key2 = []
        for key, value in request.form.items():
            if value == 'on':  # Check if the checkbox was checked
                parts = key.split("-")
                if len(parts) == 2:  # Ensure exactly two parts after splitting
                    category, item = parts
                    key1.append(category.strip())  # Strip extra spaces
                    key2.append(item.strip())      # Strip extra spaces
                else:
                    print(f"Illegal key format: {key}")
        delete_items(key1=key1,key2=key2)
        
        return render_template('RemoveItem.html')
    else:
        return "Nothing to Remove!!"

if __name__ == "__main__":
    app.run(debug=True)

    
    
    # Dont forgot to do something for username adn aopsswodrd