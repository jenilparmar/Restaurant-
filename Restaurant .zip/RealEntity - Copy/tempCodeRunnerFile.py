client = pymongo.MongoClient("mongodb://localhost:27017")
db = client["Restaurant"]
collection = db["Items"]
items_cursor= collection.find()
k = []
for item  in items_cursor:
    k.append(item)
del k[0]['_id']
ITEMS = k[0]

def AddToDatabase(thali, dish,price):
    data = collection.find_one({},{thali:ITEMS[thali]})
    data[dish]=f'{price}'
    print(data)
    return
